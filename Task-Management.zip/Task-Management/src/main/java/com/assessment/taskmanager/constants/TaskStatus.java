package com.assessment.taskmanager.constants;

import lombok.Getter;

@Getter
public enum TaskStatus {

    PENDING("PENDING"),
    IN_PROGRESS("IN_PROGRESS"),
    DONE("DONE");

    public final String value;

    TaskStatus(String value) {
        this.value = value;
    }
}
