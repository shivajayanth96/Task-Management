package com.assessment.taskmanager.request;

import java.sql.Date;

import com.assessment.taskmanager.constants.TaskStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateTaskRequest {

    @NotBlank(message = "title is required")
    private String title;
    private String description;

    private TaskStatus status = TaskStatus.PENDING;

    @NotNull(message = "due_date is required")
    @Future(message = "due_date must be in the future")
    @JsonProperty("due_date")
    private Date dueDate;
}
