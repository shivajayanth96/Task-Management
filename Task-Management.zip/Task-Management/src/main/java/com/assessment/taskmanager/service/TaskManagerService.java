package com.assessment.taskmanager.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.assessment.taskmanager.constants.TaskStatus;
import com.assessment.taskmanager.entity.Task;
import com.assessment.taskmanager.exception.NotFoundException;
import com.assessment.taskmanager.repository.TaskRepository;
import com.assessment.taskmanager.request.CreateTaskRequest;
import com.assessment.taskmanager.request.UpdateTaskRequest;
import com.assessment.taskmanager.response.TaskResponse;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class TaskManagerService {

    private static final Logger log = LoggerFactory.getLogger(TaskManagerService.class);

    private final TaskRepository repository;

    public TaskManagerService(TaskRepository repository) {
        this.repository = repository;
    }

    public TaskResponse createTask(CreateTaskRequest request) {
        Task task = new Task();
        task.setId(UUID.randomUUID().toString());
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setStatus(request.getStatus());
        task.setDueDate(request.getDueDate());
        repository.save(task);
        log.info("Saved new task with id={} and title={}", task.getId(), task.getTitle());
        return toResponse(task);
    }

    public TaskResponse getTask(String id) {
        Task task = repository.findById(id).orElseThrow(() -> new NotFoundException("Task not found"));
        log.info("Loaded task with id={}", id);
        return toResponse(task);
    }

    public TaskResponse updateTask(UpdateTaskRequest request, String id) {
        Task task = repository.findById(id).orElseThrow(() -> new NotFoundException("Task not found"));
        if (request.getTitle() != null) {
            task.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            task.setDescription(request.getDescription());
        }
        if (request.getStatus() != null) {
            task.setStatus(request.getStatus());
        }
        if (request.getDueDate() != null) {
            task.setDueDate(request.getDueDate());
        }
        repository.save(task);
        log.info("Updated task with id={}", id);
        return toResponse(task);
    }

    public void deleteTask(String id) {
        if (repository.findById(id).isEmpty()) {
            log.warn("Delete request for missing task id={}", id);
            throw new NotFoundException("Task not found");
        }
        repository.delete(id);
        log.info("Deleted task with id={}", id);
    }

    public List<TaskResponse> listTasks(int page, int size, TaskStatus status) {
        List<Task> tasks = (status == null) ? repository.findAll() : repository.findByStatus(status);
        tasks.sort((a, b) -> a.getDueDate().compareTo(b.getDueDate()));

        int fromIndex = (Math.max(page, 1) - 1) * Math.max(size, 1);
        int toIndex = Math.min(fromIndex + Math.max(size, 1), tasks.size());

        if (fromIndex >= tasks.size()) {
            log.info("No tasks found for page={}, size={}, status={}", page, size, status);
            return List.of();
        }

        List<TaskResponse> result = tasks.subList(fromIndex, toIndex).stream().map(this::toResponse)
                .collect(Collectors.toList());
        log.info("Returning {} tasks for page={}, size={}, status={}", result.size(), page, size, status);
        return result;
    }

    private TaskResponse toResponse(Task task) {
        TaskResponse response = new TaskResponse();
        response.setId(task.getId());
        response.setTitle(task.getTitle());
        response.setDescription(task.getDescription());
        response.setStatus(task.getStatus().name());
        response.setDueDate(task.getDueDate());
        return response;
    }
}
