package com.assessment.taskmanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.assessment.taskmanager.constants.ApiConstant;
import com.assessment.taskmanager.constants.TaskStatus;
import com.assessment.taskmanager.request.CreateTaskRequest;
import com.assessment.taskmanager.request.UpdateTaskRequest;
import com.assessment.taskmanager.response.TaskResponse;
import com.assessment.taskmanager.service.TaskManagerService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping(ApiConstant.TASKS_BASE_PATH)
public class TaskManagerController {

    private static final Logger log = LoggerFactory.getLogger(TaskManagerController.class);

    private final TaskManagerService service;

    public TaskManagerController(TaskManagerService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<TaskResponse> createTask(@Valid @RequestBody CreateTaskRequest request) {
        log.info("Creating task with title={}", request.getTitle());
        TaskResponse response = service.createTask(request);
        log.info("Task created successfully with id={}", response.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping(ApiConstant.TASK_BY_ID_PATH)
    public TaskResponse getTask(@PathVariable String id) {
        log.info("Fetching task with id={}", id);
        TaskResponse response = service.getTask(id);
        log.info("Task fetched successfully with id={}", id);
        return response;
    }

    @PutMapping(ApiConstant.TASK_BY_ID_PATH)
    public TaskResponse updateTask(@PathVariable String id, @Valid @RequestBody UpdateTaskRequest request) {
        log.info("Updating task with id={} and status={}", id, request.getStatus());
        TaskResponse response = service.updateTask(request, id);
        log.info("Task updated successfully with id={}", id);
        return response;
    }

    @DeleteMapping(ApiConstant.TASK_BY_ID_PATH)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTask(@PathVariable String id) {
        log.info("Deleting task with id={}", id);
        service.deleteTask(id);
        log.info("Task deleted successfully with id={}", id);
    }

    @GetMapping
    public List<TaskResponse> listTasks(
            @RequestParam(defaultValue = ApiConstant.DEFAULT_PAGE) int page,
            @RequestParam(defaultValue = ApiConstant.DEFAULT_SIZE) int size,
            @RequestParam(required = false, name = ApiConstant.STATUS_PARAM) TaskStatus status) {
        log.info("Listing tasks with page={}, size={}, status={}", page, size, status);
        List<TaskResponse> response = service.listTasks(page, size, status);
        log.info("Listed {} tasks", response.size());
        return response;
    }
}
