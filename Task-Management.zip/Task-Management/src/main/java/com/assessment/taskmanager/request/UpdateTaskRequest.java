package com.assessment.taskmanager.request;

import java.sql.Date;

import com.assessment.taskmanager.constants.TaskStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.Future;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UpdateTaskRequest {

    private String title;
    private String description;
    private TaskStatus status;
    @JsonProperty("due_date")
    @Future(message = "due_date must be in the future")
    private Date dueDate;

}
