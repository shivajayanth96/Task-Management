package com.assessment.taskmanager.repository;

import java.util.List;
import java.util.Optional;

import com.assessment.taskmanager.constants.TaskStatus;
import com.assessment.taskmanager.entity.Task;

public interface TaskRepository {

    Task save(Task task);

    Optional<Task> findById(String id);

    void delete(String id);

    List<Task> findAll();

    List<Task> findByStatus(TaskStatus status);
}
