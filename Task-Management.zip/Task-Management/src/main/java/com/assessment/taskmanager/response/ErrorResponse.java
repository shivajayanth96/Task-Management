package com.assessment.taskmanager.response;

import java.time.Instant;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorResponse {

    private int status;
    private String error;
    private Map<String, String> details;
    private Instant timestamp;

    public ErrorResponse(int status, String error, Map<String, String> details, Instant timestamp) {
        this.status = status;
        this.error = error;
        this.details = details;
        this.timestamp = timestamp;
    }
}
