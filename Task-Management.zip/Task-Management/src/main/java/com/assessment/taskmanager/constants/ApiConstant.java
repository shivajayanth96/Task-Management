package com.assessment.taskmanager.constants;

public final class ApiConstant {

    private ApiConstant() {
    }

    public static final String TASKS_BASE_PATH = "/tasks";
    public static final String TASK_BY_ID_PATH = "/{id}";
    public static final String PAGE_PARAM = "page";
    public static final String SIZE_PARAM = "size";
    public static final String STATUS_PARAM = "status";
    public static final String DEFAULT_PAGE = "1";
    public static final String DEFAULT_SIZE = "10";
}
