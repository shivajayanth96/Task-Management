package com.assessment.taskmanager.entity;

import java.sql.Date;

import com.assessment.taskmanager.constants.TaskStatus;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Task {

    private String id;
    private String title;
    private String description;
    private TaskStatus status;
    private Date dueDate;
}
