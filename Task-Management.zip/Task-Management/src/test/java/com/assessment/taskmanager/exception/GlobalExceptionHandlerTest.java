package com.assessment.taskmanager.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.assessment.taskmanager.response.ErrorResponse;

class GlobalExceptionHandlerTest {

    @Test
    void shouldHandleValidationExceptions() {
        GlobalExceptionHandler handler = new GlobalExceptionHandler();
        BindingResult bindingResult = new BeanPropertyBindingResult(
                new com.assessment.taskmanager.request.CreateTaskRequest(), "request");
        bindingResult.rejectValue("title", "title", "title is required");
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(null, bindingResult);

        ResponseEntity<ErrorResponse> response = handler.handleValidationExceptions(ex);

        assertEquals(400, response.getBody().getStatus());
        assertEquals("Validation failed", response.getBody().getError());
        assertEquals("title is required", response.getBody().getDetails().get("title"));
    }

    @Test
    void shouldHandleNotFoundExceptions() {
        GlobalExceptionHandler handler = new GlobalExceptionHandler();
        NotFoundException ex = new NotFoundException("Task not found");

        ResponseEntity<ErrorResponse> response = handler.handleNotFound(ex);

        assertEquals(404, response.getBody().getStatus());
        assertEquals("Task not found", response.getBody().getError());
    }
}
