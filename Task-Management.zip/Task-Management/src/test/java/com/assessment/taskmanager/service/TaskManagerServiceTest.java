package com.assessment.taskmanager.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.Date;
import java.util.Optional;

import com.assessment.taskmanager.constants.TaskStatus;
import com.assessment.taskmanager.entity.Task;
import com.assessment.taskmanager.exception.NotFoundException;
import com.assessment.taskmanager.repository.TaskRepository;
import com.assessment.taskmanager.request.CreateTaskRequest;
import com.assessment.taskmanager.request.UpdateTaskRequest;
import com.assessment.taskmanager.response.TaskResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TaskManagerServiceTest {

    @Mock
    private TaskRepository repository;

    @InjectMocks
    private TaskManagerService service;

    private Task task;

    @BeforeEach
    void setUp() {

        task = new Task();
        task.setId("1");
        task.setTitle("Task 1");
        task.setDescription("Description");
        task.setStatus(TaskStatus.PENDING);
        task.setDueDate(Date.valueOf("2025-01-01"));
    }

    @Test
    void testCreateTask() {

        CreateTaskRequest request = new CreateTaskRequest();
        request.setTitle("Task 1");
        request.setDescription("Description");
        request.setStatus(TaskStatus.PENDING);
        request.setDueDate(Date.valueOf("2025-01-01"));

        when(repository.save(ArgumentMatchers.any(Task.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        TaskResponse response = service.createTask(request);

        assertNotNull(response);
        assertNotNull(response.getId());
        assertEquals("Task 1", response.getTitle());
        assertEquals("Description", response.getDescription());
        assertEquals("PENDING", response.getStatus());

        verify(repository).save(any(Task.class));
    }

    @Test
    void testGetTask() {

        when(repository.findById("1")).thenReturn(Optional.of(task));

        TaskResponse response = service.getTask("1");

        assertEquals("1", response.getId());
        assertEquals("Task 1", response.getTitle());

        verify(repository).findById("1");
    }

    @Test
    void testGetTask_NotFound() {

        when(repository.findById("1")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> service.getTask("1"));
    }

    @Test
    void testUpdateTask() {

        UpdateTaskRequest request = new UpdateTaskRequest();
        request.setTitle("Updated Task");
        request.setDescription("Updated Description");
        request.setStatus(TaskStatus.DONE);
        request.setDueDate(Date.valueOf("2025-02-01"));

        when(repository.findById("1")).thenReturn(Optional.of(task));
        when(repository.save(any(Task.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        TaskResponse response = service.updateTask(request, "1");

        assertEquals("Updated Task", response.getTitle());
        assertEquals("Updated Description", response.getDescription());
        assertEquals("DONE", response.getStatus());

        verify(repository).save(task);
    }

    @Test
    void testUpdateTask_NotFound() {

        UpdateTaskRequest request = new UpdateTaskRequest();

        when(repository.findById("1")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> service.updateTask(request, "1"));
    }

    @Test
    void testDeleteTask() {

        when(repository.findById("1")).thenReturn(Optional.of(task));

        doNothing().when(repository).delete("1");

        service.deleteTask("1");

        verify(repository).delete("1");
    }

    @Test
    void testDeleteTask_NotFound() {

        when(repository.findById("1")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> service.deleteTask("1"));

        verify(repository, never()).delete(anyString());
    }
}