package com.assessment.taskmanager.controller;

import com.assessment.taskmanager.constants.ApiConstant;
import com.assessment.taskmanager.constants.TaskStatus;
import com.assessment.taskmanager.request.CreateTaskRequest;
import com.assessment.taskmanager.request.UpdateTaskRequest;
import com.assessment.taskmanager.response.TaskResponse;
import com.assessment.taskmanager.service.TaskManagerService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
class TaskManagerControllerTest {

        @Autowired
        private MockMvc mockMvc;

        @Mock
        private TaskManagerService service;

        @InjectMocks
        private TaskManagerController controller;

        @BeforeEach
        void setup() {
                mockMvc = org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup(controller)
                                .build();
        }

        @Test
        void shouldCreateTask() throws Exception {

                ObjectMapper objectMapper = new ObjectMapper();

                CreateTaskRequest request = new CreateTaskRequest();
                request.setTitle("Learn Spring");
                request.setDescription("Practice MVC");
                request.setStatus(TaskStatus.PENDING);
                request.setDueDate(new java.sql.Date(System.currentTimeMillis() + 86_400_000));

                TaskResponse response = new TaskResponse();
                response.setId("1");
                response.setTitle("Learn Spring");
                response.setDescription("Practice MVC");
                response.setStatus(TaskStatus.PENDING.getValue());

                Mockito.when(service.createTask(any()))
                                .thenReturn(response);

                mockMvc.perform(post(ApiConstant.TASKS_BASE_PATH)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(objectMapper.writeValueAsString(request)))
                                .andExpect(status().isCreated());
        }

        @Test
        void shouldGetTask() throws Exception {

                TaskResponse response = new TaskResponse();
                response.setId("1");
                response.setTitle("Task");
                response.setStatus(TaskStatus.PENDING.getValue());

                Mockito.when(service.getTask("1"))
                                .thenReturn(response);

                mockMvc.perform(get(ApiConstant.TASKS_BASE_PATH + "/1"))
                                .andExpect(status().isOk())
                                .andExpect(jsonPath("$.id").value("1"))
                                .andExpect(jsonPath("$.title").value("Task"));
        }

        @Test
        void shouldUpdateTask() throws Exception {
                ObjectMapper objectMapper = new ObjectMapper();

                UpdateTaskRequest request = new UpdateTaskRequest();
                request.setStatus(TaskStatus.DONE);

                TaskResponse response = new TaskResponse();
                response.setId("1");
                response.setStatus(TaskStatus.DONE.getValue());

                Mockito.when(service.updateTask(any(UpdateTaskRequest.class), eq("1")))
                                .thenReturn(response);

                mockMvc.perform(put(ApiConstant.TASKS_BASE_PATH + "/1")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(objectMapper.writeValueAsString(request)))
                                .andExpect(status().isOk());
        }

        @Test
        void shouldDeleteTask() throws Exception {

                Mockito.doNothing().when(service).deleteTask("1");

                mockMvc.perform(delete(ApiConstant.TASKS_BASE_PATH + "/1"))
                                .andExpect(status().isNoContent());

                Mockito.verify(service).deleteTask("1");
        }

        @Test
        void shouldListAllTasks() throws Exception {

                TaskResponse task1 = new TaskResponse();
                task1.setId("1");
                task1.setTitle("Task1");
                task1.setStatus(TaskStatus.PENDING.getValue());

                TaskResponse task2 = new TaskResponse();
                task2.setId("2");
                task2.setTitle("Task2");
                task2.setStatus(TaskStatus.DONE.getValue());

                mockMvc.perform(get(ApiConstant.TASKS_BASE_PATH))
                                .andExpect(status().isOk());
        }

        @Test
        void shouldFilterTasksByStatus() throws Exception {

                TaskResponse task = new TaskResponse();
                task.setId("1");
                task.setStatus(TaskStatus.DONE.getValue());

                mockMvc.perform(get(ApiConstant.TASKS_BASE_PATH)
                                .param("status", "DONE"))
                                .andExpect(status().isOk());
        }
}
