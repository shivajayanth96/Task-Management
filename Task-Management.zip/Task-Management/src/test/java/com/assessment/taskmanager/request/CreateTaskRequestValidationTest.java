package com.assessment.taskmanager.request;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;

class CreateTaskRequestValidationTest {

    private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    @Test
    void shouldFailWhenTitleIsBlank() {
        CreateTaskRequest request = new CreateTaskRequest();
        request.setTitle("   ");
        request.setDueDate(new Date(System.currentTimeMillis() + 24_000L * 60L * 60L));

        Set<ConstraintViolation<CreateTaskRequest>> violations = validator.validate(request);

        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> "title is required".equals(v.getMessage())));
    }

    @Test
    void shouldFailWhenDueDateIsInPast() {
        CreateTaskRequest request = new CreateTaskRequest();
        request.setTitle("Valid title");
        request.setDueDate(new Date(System.currentTimeMillis() - 24_000L * 60L * 60L));

        Set<ConstraintViolation<CreateTaskRequest>> violations = validator.validate(request);

        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> "due_date must be in the future".equals(v.getMessage())));
    }
}
